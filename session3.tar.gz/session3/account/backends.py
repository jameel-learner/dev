from .models import User
from django.contrib.auth import get_user_model
from django.db.models import Q


class AuthBackend(object):
    supports_object_permissions = True
    supports_anonymous_user = False
    supports_inactive_user = False


    def get_user(self, user_id):
        print("Calling My USer model now")
        try:
            return User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return None

    def authenticate(self, username=None, password=None):
        print("Calling My USer model now")
        mobile_number = None
        email = None
        try:
            mobile_number = int(username)
        except:
            email = username
        try:
            if mobile_number:
                user = User.objects.get(mobile_number=username)
            if email:
                user = User.objects.get(username=username)

        except User.DoesNotExist:
            return None
        if password is None:
            return user if user else None
        return user if user.check_password(password) else None

    def get_user(self, username):
        print("Calling My USer model now")
        try:
            return get_user_model().objects.get(pk=username)
        except get_user_model().DoesNotExist:
            return None
