from django.shortcuts import render, redirect

from django.contrib.auth import login, logout
from django.contrib.auth.hashers import make_password
from django.contrib import messages
from .backends import AuthBackend
from django.http import HttpResponse, HttpResponseRedirect
import json
from .decorator import user_login_required
from .models import *
from django.db.models import *              # for aggregate(Sum())
# from sales.models import SalesOrder

# Create your views here.
# #########################################################################
# User
#     Registration                          | Verification, Activation
#     Login
#     Logout
#     Forgot
#
#     Product Rating                        | Rating Notification, Post SOs Completion
#     Customer Service Reviews              | Review Notification, Post SOs Completion
# #########################################################################

def register(request):
    print("reached register")

    if request.method == 'POST':
        first_name = request.POST.get('ds_fname')
        last_name = request.POST.get('ds_lname')
        email = request.POST.get('ds_mail')
        mobile_number = request.POST.get('ds_num')
        password = request.POST.get('dl_pass')
        confirm_password = request.POST.get('ds_confirm_password')
        username = request.POST.get('dl_uname')
        # if password != confirm_password:
        #     messages.warning(request, "Your password and confirmation password do not match.")
        # else:
        #     user = User.objects.filter(email=email, role__name="Guest")
        #     if user:
        #         User.objects.filter(email=email).update(first_name=first_name, last_name=last_name, dob=dob,
        #                                                 mobile_number=mobile_number, address=residential_address,
        #                                                 state=state, postal_code=postal_code, country=country,
        #                                                 city=city, password=make_password(password))
        #         user_obj = User.objects.get(email=email)
        #         role_rec = UserRole.objects.get(name='Donor')
        #         exit_role = UserRole.objects.get(name='Guest')
        #         user_obj.role.remove(exit_role)
        #         user_obj.role.add(role_rec)
        #     else:
        #         user_obj = User.objects.create(first_name=first_name, last_name=last_name, dob=dob, email=email,
        #                                        mobile_number=mobile_number, address=residential_address,
        #                                        state=state,
        #                                        postal_code=postal_code, country=country, city=city,
        #                                        username=username,
        #                                        password=make_password(password), is_active=True)
        #         role_rec = UserRole.objects.get(name='Donor')
        #         user_obj.role.add(role_rec)
        #         login(request, user_obj, backend='accounts.backends.AuthBackend')
        #         dashboard_path = user_obj.get_dashboard_path()
        #         return redirect(dashboard_path)
        #     messages.success(request, "User Created Successfully!")
        #     return redirect('/account/login_user/')
        # return render(request, 'signup.html')

        user_obj = User.objects.create(first_name=first_name, last_name=last_name, email=email,
                        mobile_number=mobile_number, username=username,
                        password=make_password(password), is_active=True)
        return redirect('account:login_user')

    return render(request,'register.html')

def login_user(request):
    print("reached login_user")

    if request.method == 'POST':
        username = request.POST.get('dl_uname')
        password = request.POST.get('dl_pass')
        auth_obj = AuthBackend()
        user = auth_obj.authenticate(username=username, password=password)
        if user is not None:
            login(request, user, backend='account.backends.AuthBackend')
            dashboard_path = user.get_dashboard_path()
            return redirect(dashboard_path)
        else:
            messages.warning(request, "Enter Valid Username and Password.")
            return redirect('account:login_user')

    return render(request,'login.html')

def logout_user(request):
    print("reached logout_user")

    user = request.user
    # if not user.dob and not user.email:
    # if not user.social_auth.all():
    #     if not user.dob:
    #         user.is_active = False
    #         user.save()
    # print(f"user :{user.id} ")
    if AvoidMultipleCheckout.objects.filter(user_id=user.id).exists():
        del_rec = AvoidMultipleCheckout.objects.get(user_id=user.id).delete()
    # if UserCart.objects.filter(user_id=user.id, is_paid=False).exists():
    #     uc = UserCart.objects.filter(user_id=user.id, is_paid=False).update(order_no=None)
    #     # uc.save()

    logout(request)
    request.session.flush()
    return redirect('/')
    # return render(request,'logout_user.html')

def forgot(request):
    print("reached forgot")
    return render(request,'forgot.html')

def product_rating(request):
    print("reached product_rating")
    return render(request,'product_rating.html')

def customer_service_review(request):
    print("reached customer_service_review")
    return render(request,'customer_service_review.html')


# #########################################################################
# Cart
# 	Add to Cart 							| Add Cart Item
# 	View Cart 								| Remove
# 	Checkout
# 	Get Quote								| Quotation Append to Cart Item
# 	Raise Logistics Service Request 		| logistic:service_enquiry_request
#
# 	View Wishlist 							| Remove
# 	Wishlist Add to Cart					| Wishlist Notification
#
# 	CheckOut - CustomerSalesOrder			| sales:customer_sales_order
# 	CustomerSalesOrder Status Tracking 		| sales:sales_order_tracking
# #########################################################################

@user_login_required
def add_to_cart(request):
    print("reached add_to_cart")

    if request.user.is_authenticated:
        if request.method == 'POST':
            product_id = request.POST.get('product_id')
            product = Product.objects.get(pk=product_id)
            amount = request.POST.get('amount')
            user_data = request.session['_auth_user_id']
            user = User.objects.get(id=user_data)

            # Once User Confirms his SalesOrder, entry is made in this table
            if AvoidMultipleCheckout.objects.filter(user_id=user.id).exists():
                content = {'message': 'Cannot Add to Cart!!', 'reason': 'Cart Already In Process of Checkout'}
            else:
                uc = UserCart.objects.filter(product=product, user=user, is_paid=False).exists()
                if uc is not True:
                    UserCart.objects.create(product=product, user=user, amount=amount)
                    content = {'message': 'Added to cart!!'}
                else:
                    UserCart.objects.filter(product=product, user=user, is_paid=False).update(amount=amount)
                    content = {'message': 'Updated!!'}
            response = HttpResponse(json.dumps(content))
            return response
    # else:
    #     if request.method == 'POST':
    #         if 'amount' in request.COOKIES.keys():
    #             del request.COOKIES['amount']
    #         if 'slider_donation_id' in request.COOKIES.keys():
    #             del request.COOKIES['slider_donation_id']
    #         if 'sponserships_type' in request.COOKIES.keys():
    #             del request.COOKIES['sponserships_type']
    #         if 'projects_type' in request.COOKIES.keys():
    #             del request.COOKIES['projects_type']
    #         if 'campaigns_handouts' in request.COOKIES.keys():
    #             del request.COOKIES['campaigns_handouts']
    #         if 'category' in request.COOKIES.keys():
    #             del request.COOKIES['category']
    #         if 'borrower' in request.COOKIES.keys():
    #             del request.COOKIES['borrower']
    #
    #         borrower_id = request.POST.get('borrower_id')
    #         borrower = BorrowersDetails.objects.get(pk=borrower_id)
    #         category_id = category_details.objects.get(pk=borrower.category.id)
    #         amount = request.POST.get('amount')
    #         content = {'message': 'Please Log in !!', 'borrower': borrower.id, 'category': category_id.id,
    #                    'amount': amount}
    #         response = HttpResponse(json.dumps(content))
    #         return response
    #
    content = {'message': 'Please Log in !!'}
    response = HttpResponse(json.dumps(content))
    return response

    # return render(request,'add_to_cart.html')

@user_login_required
def view_cart(request):
    print("reached view_cart")

    if request.user.is_authenticated:
        user_data = request.session['_auth_user_id']
        user = User.objects.get(id=user_data)
        cartdetail = []
        if UserCart.objects.filter(user=user).exists():
            # uc = UserCart.objects.filter(user=user, is_paid=False).select_related()
            # for u in uc:
            #     userdata = {}
            #     userCart = UserCart.objects.filter(pk=u.id).values()
            #
            #     # Category
            #     if category_details.objects.filter(pk=u.category_id):
            #         categoryInfo = category_details.objects.filter(pk=u.category_id)
            #         userdata['categoryInfo'] = (list(categoryInfo)[0])
            #     else:
            #         userdata['categoryInfo'] = None
            #     # Sponser
            #     if SponsershipDetails.objects.filter(pk=u.sponsership_donation_id):
            #         sponserInfo = SponsershipDetails.objects.filter(pk=u.sponsership_donation_id)
            #         userdata['sponserInfo'] = (list(sponserInfo)[0])
            #     else:
            #         userdata['sponserInfo'] = None
            #
            #     # Project
            #     if ProjectDetails.objects.filter(pk=u.project_donation_id):
            #         projectInfo = ProjectDetails.objects.filter(pk=u.project_donation_id)
            #         userdata['projectInfo'] = (list(projectInfo)[0])
            #     else:
            #         userdata['projectInfo'] = None
            #
            #     # Campaign
            #     if CampaignDetails.objects.filter(pk=u.campaign_donation_id):
            #         campaignInfo = CampaignDetails.objects.filter(pk=u.campaign_donation_id)
            #         userdata['campaignInfo'] = (list(campaignInfo)[0])
            #     else:
            #         userdata['campaignInfo'] = None
            #     # Slider
            #     if SliderDetails.objects.filter(pk=u.slider_donation_id):
            #         sliderInfo = SliderDetails.objects.filter(pk=u.slider_donation_id)
            #         userdata['sliderInfo'] = (list(sliderInfo)[0])
            #     else:
            #         userdata['sliderInfo'] = None
            #
            #     # Borrower
            #     if BorrowersDetails.objects.filter(pk=u.borrower_id, is_approve=True):
            #         borrowerInfo = BorrowersDetails.objects.filter(pk=u.borrower_id, is_approve=True)
            #         userdata['borrowerInfo'] = (list(borrowerInfo)[0])
            #     else:
            #         userdata['borrowerInfo'] = None
            #
            #     userdata['userCart'] = (list(userCart)[0])
            #     cartdetail.append(userdata)
            usercart = UserCart.objects.filter(user=user, is_paid=False)
            productCount = UserCart.objects.filter(user=user, is_paid=False).count()
            sumAmount = UserCart.objects.filter(user=user, is_paid=False).aggregate(Sum('amount'))
            # amt = UserCart.objects.filter(user__id=user_data, is_paid=False).aggregate(Sum('amount'))

            ###########################################################################
            # host = request.get_host()
            # if amt['amount__sum'] is not None:
            #     paypal_dict = {
            #         'bussiness': settings.PAYPAL_RECEIVER_EMAIL,
            #         'amount': amt['amount__sum'],
            #         'notify_url': 'http://{}{}'.format(host, reverse('paypal-ipn')),
            #         'return_url': 'http://{}{}'.format(host, reverse('payment:done')),
            #         'cancle_return': 'http://{}{}'.format(host, reverse('payment:canceled')),
            #     }
            #     form = PayPalPaymentsForms(initial=paypal_dict)
            #     return render(request, 'view_cart.html',
            #                   {'cartdetail': cartdetail, 'sumAmount': sumAmount, 'productCount': productCount,
            #                    'form': form})
            ###########################################################################

            return render(request, 'view_cart.html',
                          {'cartdetail': usercart, 'sumAmount': sumAmount, 'productCount': productCount})
        else:
            return render(request, 'view_cart.html', {})
    else:
        return redirect('accounts:login_user')

    # return render(request,'view_cart.html')

def product_quote(request):
    print("reached product_quote")
    return render(request,'product_quote.html')

# Overridden by sales/confirm_sales_order invoked from account/view_cart
def checkout(request):
    print("reached checkout")
    return render(request,'checkout.html')

# def sales_order(request):
#     print("reached sales_order")
#     return render(request,'confirm_sales_order.html')
#
# def sales_order_tracking(request):
#     print("reached sales_order_tracking")
#     return render(request,'sales_order_tracking.html')

def view_wishlist(request):
    print("reached view_wishlist")
    return render(request,'view_wishlist.html')

def wishlist_add_to_cart(request):
    print("reached wishlist_add_to_cart")
    return render(request,'wishlist_add_to_cart.html')
