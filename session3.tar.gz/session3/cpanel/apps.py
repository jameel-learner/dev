from django.apps import AppConfig


class CpanelConfig(AppConfig):
    name = 'cpanel'
