from django.shortcuts import render

# Create your views here.
# ##########################################################################
#
# ERP Features - CPanel
#
#
# ##########################################################################

def index(request):
    print("reached index")
    return render(request,'index.html')
