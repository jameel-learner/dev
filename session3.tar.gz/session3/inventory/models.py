from django.db import models

# Create your models here.
# <inventory>
# 	StockPerProductSpecification				| InHouse | Trading (3rd Party Ready Stock)
