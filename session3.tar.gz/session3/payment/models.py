from django.db import models
from sales.models import SalesOrder
from account.models import User

# Create your models here.
# <payment>
# 	SalesPaymentRecord
# 	SalesPaymentTransactionLog
# 	PurchasePaymentRecord
# 	PurchasePaymentTransactionLog
# 	LogisticsPaymentRecord
# 	LogisticsPaymentTransactionRecord


class SalesPaymentRecord(models.Model):
    STATUS_TYPE = [('Initiated', 'Initiated'), ('Rejected', 'Rejected'), ('Refunded', 'Refunded'),
                   ('Accepted', 'Accepted'), ('Canceled', 'Canceled'),('Processing', 'Processing')]
    user = models.ForeignKey(User, null=True, related_name='credit_amt', on_delete=models.CASCADE)
    order = models.ForeignKey(SalesOrder, null=True, blank=True, related_name='sales_payment', on_delete=models.CASCADE)

    credit_amt = models.FloatField(blank=True, null=True)
    debit_amt = models.FloatField(blank=True, null=True)
    credit_date = models.DateField(blank=True, auto_now_add=True, null=True)
    debit_date = models.DateField(blank=True, null=True)

    receipt_no = models.CharField(max_length=500, null=True, blank=True)
    pay_mode = models.CharField(max_length=500, null=True, blank=True)
    status = models.CharField(choices=STATUS_TYPE, default='Accepted', max_length=50)
    append_comment = models.TextField(blank=True, null=True)


class SalesPaymentTransactionLog(models.Model):
    user = models.ForeignKey(User, null=True, related_name='payment_transaction_log', on_delete=models.CASCADE)
    api_name = models.CharField(max_length=50, null=True, blank=True)
    request_text = models.TextField(blank=True, null=True)
    url = models.TextField(blank=True, null=True)
    response_text = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=50, null=True, blank=True)
    message = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    update_on = models.DateField(auto_now=True)

    class Meta:
        get_latest_by = 'created_at'
