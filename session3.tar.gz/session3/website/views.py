from django.shortcuts import render

# Create your views here.
##########################################################################
# Website Features
# ##########################################################################
#
# Home Page (Sub Sections)
# 	Header
# 		Phone | Email | Language | Register | Sign IN
# 		LOGO | Product Search | WishList | Cart
# 		Horizontal Menu Bar
# 			Home | Shop | Categories | Deals | Brands | Contact Us
#
# 	Deals of the Week
# 		Featured
# 		On Sale
# 		Best Rated
#
# 	Popular Categories
#
# 	Best Products Slide Show (Limited count)
#
# 	Hot New Arrivals
# 		Featured
# 		Categories (that have Hot products)
#
# 	Hot Best Sellers
# 		Top 20
# 		Categories (that have Best Sellers)
#
# 	Trends 2020
#
# 	Latest Reviews
#
# 	Recently Viewed
#
# 	Famous Product Brand Logos @ Our Store
#
# 	Subsciption Form
#
# 	Footer
# 		Contact Us (Physical | Phone | Email | Social Media Links)
# 		Quick Links
#
# ##########################################################################
def home(request):
    print("reached home")
    return render(request,'home.html')

def contact_us(request):
    print("reached contact_us")
    return render(request,'contact_us.html')
