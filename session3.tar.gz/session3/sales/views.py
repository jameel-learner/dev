from django.shortcuts import render, redirect

from django.http import HttpResponse, HttpResponseRedirect
import json
from datetime import datetime
from account.models import User, UserCart
from .utils import render_to_pdf, generate_salesorder_number
from account.decorator import user_login_required
from .models import *

# Create your views here.
# ##########################################################################
#
# ERP Feature: Sales Order Mgmt
#   CustomerSalesOrder					| SOs
# 	SalesInvoicePDFs -- CheckoutOrder
# 	SalesOrder Status Tracking --
# 		CustomerSalesOrder -- | Confirmed | Paid | Dispatched | Delivered |
#
# 	SalesOrder Payment Collection       | payment:sales_order_payment_collection
# ##########################################################################
@user_login_required
def confirm_sales_order(request):
    print("reached confirm_sales_order")

    # Not required as we have decorator @user_login_required
    if request.user.is_authenticated:
        if request.method == 'POST':
            sumAmount = request.POST.get('amount')

            user_id = request.session['_auth_user_id']
            user = User.objects.get(id=user_id)
            print(user)
            perfoma_salesorder = SalesOrder.objects.create(number=generate_salesorder_number(), amount=sumAmount)
            UserCart.objects.filter(user=user, is_paid=False).update(sales_order=perfoma_salesorder)

            context = { 'sales_order':perfoma_salesorder }

            return render(request,'salesorder_invoice_template.html', {'cx':context})
    else:
        return redirect('account:login_user')

    # return render(request,'confirm_sales_order.html')


def sales_order_invoice_pdf(request):
    print("reached sales_order_invoice_pdf")

    sales_order_id = request.POST.get('sales_order_id')
    sales_order = SalesOrder.objects.get(id=sales_order_id)
    params = {
        'sales_order': sales_order,
        'logo': '/static/Book2_files/Book2_26147_image001.png'
    }
    try:
        file = render_to_pdf('recipt.html', params)
        print(f"Success file : {file} ")
        return file
    except Exception as ee:
        print(ee)
        context = {'error': 'Something went wrong!!'}
        return HttpResponse(json.dumps(context), content_type="application/json")
    # return render(request,'salesorder_invoice_template.html')

def sales_order_tracking(request):
    print("reached sales_order_tracking")
    return render(request,'sales_order_tracking.html')
