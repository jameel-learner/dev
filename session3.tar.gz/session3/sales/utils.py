from random import *
import string
import datetime
from django.template.loader import get_template
from io import BytesIO
import xhtml2pdf.pisa as pisa
from django.http import HttpResponse


def increment_invoice_number():
    characters = string.digits
    number = "".join(choice(characters) for x in range(randint(4, 6)))
    new_receipt_no = 'DI' + "_" + str(number) + "_" + datetime.datetime.now().strftime('%Y-%m')
    return new_receipt_no

def render_to_pdf(template_src, context_dict={}):
    template = get_template(template_src)
    html = template.render(context_dict)
    result = BytesIO()
    # result = StringIO.StringIO()
    pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)
    if not pdf.err:
        return HttpResponse(result.getvalue(), content_type='application/pdf')
    return None

def generate_salesorder_number():
    return datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')

