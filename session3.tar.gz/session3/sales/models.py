from django.db import models
# from account.models import User, UserCart

# Create your models here.
# <sales>
# 	CustomerSalesOrder			| Checkout
# 	SingletonCheckout
# 	SalesInvoice

# Back references to UserCart as <salesOrder>.usercart_items
# Singleton references to MultipleCheckout as <salesOrder>.multiple_checkouts
class SalesOrder(models.Model):
    STATUS_TYPE = [('Performa', 'Performa'), ('Accepted', 'Accepted'), ('Pending', 'Pending'), ('Delivered', 'Delivered'), ('Canceled', 'Canceled')]

    number = models.CharField(max_length=500, null=True, blank=True)
    amount = models.IntegerField(blank=True, null=True)
    bank_ref_no = models.CharField(max_length=500, null=True, blank=True)

    is_paid = models.BooleanField(default=False)
    status = models.CharField(choices=STATUS_TYPE, default='Performa', max_length=50)
    invoice_pdf = models.FileField(upload_to='invoice/so', blank=True, null=True, default='defaulthadees.jpg')
    append_comment = models.TextField(blank=True, null=True)
    # user_cart = models.ManyToManyField(UserCart, blank=True, related_name='cart_saleorder')

    def __str__(self):
        return self.number

