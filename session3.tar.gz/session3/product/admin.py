from django.contrib import admin
from .models import *

# Register your models here.

class ProductAdmin(admin.ModelAdmin):
	list_display = ('name', 'mainpic', 'maincont')		#, 'belongs_to_category')
	list_filter = ( 'countSold', 'countLikes')

class ProductSpecificationAdmin(admin.ModelAdmin):
	list_display = (ProductSpecification.myself, 'value')

admin.site.register(Product, ProductAdmin)
admin.site.register(ProductSpecification, ProductSpecificationAdmin)
admin.site.register(ProductCategory)