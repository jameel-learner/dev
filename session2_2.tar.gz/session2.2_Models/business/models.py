from django.db import models
from product.models import Product

# Create your models here.
# <business>
# 	ProductFeatured
# 	ProductBestPromoted
# 	ProductBestSelling
# 	ProductBestRated
# 	ProductNewArrival
# 	ProductOnSale
# 	ProductOfferDeal			| Exchange, Buy1Get1, Discount, etc
# 	ProductRecentlyViewed
# 	ProductBrands
# 	ProductTrends2020
# 	ProductPopularCategory

class ProductFeatured(models.Model):
    product = models.ForeignKey(Product, null=True, related_name='featured', on_delete=models.CASCADE)

    def __str__(self):
        return self.product.name

class ProductOnSale(models.Model):
    product = models.ForeignKey(Product, null=True, related_name='onsale', on_delete=models.CASCADE)
    valid_till = models.DateField(blank=True, null=True)
    discount = models.FloatField(blank=True, null=True)     # Percentage in decimal

    def __str__(self):
        return self.product.name


class OfferDeal(models.Model):
    name = models.CharField(max_length=500, null=True, blank=True)
    starts_from = models.DateField(blank=True, null=True)
    ends_at = models.DateField(blank=True, null=True)

    def __str__(self):
        return self.name

class ProductOfferDeal(models.Model):
    product = models.ForeignKey(Product, null=True, related_name='on_offer', on_delete=models.CASCADE)
    offer = models.ForeignKey(OfferDeal, null=True, related_name='products_listed', on_delete=models.CASCADE)

    def __str__(self):
        return self.product.name
