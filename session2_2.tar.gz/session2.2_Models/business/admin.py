from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(ProductFeatured)
admin.site.register(ProductOnSale)
admin.site.register(ProductOfferDeal)
admin.site.register(OfferDeal)

