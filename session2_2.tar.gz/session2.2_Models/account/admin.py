from django.contrib import admin
from .models import *

# Register your models here.

class UserAdmin(admin.ModelAdmin):
	list_display = ('username', 'email', 'mobile_number', 'is_staff')
	list_filter = (  'is_staff', 'is_superuser', 'is_active')

class UserCartAdmin(admin.ModelAdmin):
	list_display = ('user', 'product', 'status', 'amount', 'is_paid', 'sales_order')
	list_filter = (  'user', 'product', 'is_paid')

admin.site.register(User, UserAdmin)
admin.site.register(UserCart, UserCartAdmin)
admin.site.register(AvoidMultipleCheckout)
