from django.db import models
from django.contrib.auth.models import AbstractUser
from product.models import Product
from sales.models import SalesOrder

# Create your models here.
# <account>
# 	User				| Login | usr, pwd, email, phone
# 	CustomerDetail
# 	Subscription
# 	Wishlist
# 	Cart
# 	ReviewComment
# 	ProductRating


class User(AbstractUser):
	# Default columns provided by django.contrib.auth.models.AbstractUser
	ID = 'id'					#, models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
	PASSWORD = 'password'		#, models.CharField(max_length=128, verbose_name='password')),
	LAST_LOGIN = 'last_login'	#, models.DateTimeField(blank=True, null=True, verbose_name='last login')),
	IS_SUPERUSER = 'is_superuser'		#, models.BooleanField(default=False, help_text='Designates that this user has all permissions without explicitly assigning them.', verbose_name='superuser status')),
	USERNAME = 'username'		#, models.CharField(error_messages={'unique': 'A user with that username already exists.'}, help_text='Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only.', max_length=150, unique=True, validators=[django.contrib.auth.validators.UnicodeUsernameValidator()], verbose_name='username')),
	FIRST_NAME = 'first_name'	#, models.CharField(blank=True, max_length=30, verbose_name='first name')),
	LAST_NAME = 'last_name'		#, models.CharField(blank=True, max_length=150, verbose_name='last name')),
	IS_STAFF = 'is_staff'		#, models.BooleanField(default=False, help_text='Designates whether the user can log into this admin site.', verbose_name='staff status')),
	IS_ACTIVE = 'is_active'		#, models.BooleanField(default=True, help_text='Designates whether this user should be treated as active. Unselect this instead of deleting accounts.', verbose_name='active')),
	DATE_JOINED = 'date_joined'	#, models.DateTimeField(default=django.utils.timezone.now, verbose_name='date joined')),
	GROUPS = 'groups'			#, models.ManyToManyField(blank=True, help_text='The groups this user belongs to. A user will get all permissions granted to each of their groups.', related_name='user_set', related_query_name='user', to='auth.Group', verbose_name='groups')),
	USER_PERMISSIONS = 'user_permissions'	#, models.ManyToManyField(blank=True, help_text='Specific permissions for this user.', related_name='user_set', related_query_name='user', to='auth.Permission', verbose_name='user permissions')),

	# Our custom addon fields
	email = models.CharField(max_length=256, blank=True, null=True)
	mobile_number = models.CharField(max_length=256,blank=True, null=True)
	encoded_pwd = models.CharField(max_length=100, blank=True, null=True)
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)

	class Meta:
		ordering = ['-id']


class UserCart(models.Model):
	STATUS_TYPE = [('AddToCart', 'AddToCart'), ('Checkout', 'Checkout')]
	user = models.ForeignKey(User, null=True, related_name='cart_owner', on_delete=models.CASCADE)
	amount = models.IntegerField(blank=True, null=True)
	product = models.ForeignKey(Product, null=True, blank=True, related_name='cart_product', on_delete=models.PROTECT)
	is_paid = models.BooleanField(default=False)
	status = models.CharField(choices=STATUS_TYPE, default='AddToCart', max_length=50)
	sales_order = models.ForeignKey(SalesOrder, null=True, related_name='usercart_items', on_delete=models.CASCADE)

	def __str__(self):
		return self.user.username +'.'+ self.product.name

class AvoidMultipleCheckout(models.Model):
    user = models.OneToOneField(User, related_name='logged_in_user1', on_delete=models.CASCADE)
    session_key = models.CharField(max_length=50, null=True, blank=True)
    amount = models.IntegerField(blank=True, null=True)
    sales_order = models.ForeignKey(SalesOrder, null=True, related_name='multiple_checkouts', on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        get_latest_by = 'created_at'

    def __str__(self):
        return self.user.username
