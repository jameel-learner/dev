from django.db import models

# Create your models here.
# CRUD
# <product>
# 	Product
# 	ProductSpecification		| Size, Color, Width, Height, etc
# 	ProductCategory

class ProductCategory(models.Model):
    name = models.CharField(max_length=255, blank=True, null=True)
    maincont = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name

class Product(models.Model):
    name = models.CharField(max_length=255, blank=False, null=False)
    mainpic = models.ImageField(upload_to='product/main_pic', blank=True, null=True, default='default300x225.jpg')
    maincont = models.TextField(blank=True, null=True)
    countSold = models.IntegerField(default=0)
    countLikes = models.IntegerField(default=0)
    category = models.ManyToManyField(ProductCategory, blank=True, related_name='belongs_to_category')

    class Meta:
        ordering = ('-id',)

    def __str__(self):
        return self.name

class ProductSpecification(models.Model):
    product = models.ForeignKey(Product, null=True, related_name='product_sec', on_delete=models.CASCADE)
    name = models.CharField(max_length=255, blank=True, null=True)
    value = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        ordering = ('product',)

    def __str__(self):
        return self.product.name +'.'+ self.name

    def myself(self):
        return self.product.name +'.'+ self.name

