from django.db import models

# Create your models here.
# <logistics>
# 	LogisticsAgent
# 	ServiceEnquiryRequest
# 	ServiceQuotation
# 	LogisticsOrder
# 	LogisticsInvoice