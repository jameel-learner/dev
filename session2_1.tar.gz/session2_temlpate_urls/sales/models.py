from django.db import models

# Create your models here.
# <sales>
# 	CustomerSalesOrder			| Checkout
# 	SingletonCheckout
# 	SalesInvoice
