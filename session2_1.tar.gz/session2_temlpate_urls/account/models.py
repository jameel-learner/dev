from django.db import models

# Create your models here.
# <account>
# 	User				| Login | usr, pwd, email, phone
# 	CustomerDetail
# 	Subscription
# 	Wishlist
# 	Cart
# 	ReviewComment
# 	ProductRating

