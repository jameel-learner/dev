from django.shortcuts import render

# Create your views here.
# #########################################################################
# User
#     Registration                          | Verification, Activation
#     Login
#     Logout
#     Forgot
#
#     Product Rating                        | Rating Notification, Post SOs Completion
#     Customer Service Reviews              | Review Notification, Post SOs Completion
# #########################################################################

def register(request):
    print("reached register")
    return render(request,'register.html')

def login(request):
    print("reached login")
    return render(request,'login.html')

def logout(request):
    print("reached logout")
    return render(request,'logout.html')

def forgot(request):
    print("reached forgot")
    return render(request,'forgot.html')

def product_rating(request):
    print("reached product_rating")
    return render(request,'product_rating.html')

def customer_service_review(request):
    print("reached customer_service_review")
    return render(request,'customer_service_review.html')


# #########################################################################
# Cart
# 	View Cart 								| Remove
# 	Checkout
# 	Get Quote								| Quotation Append to Cart Item
# 	Raise Logistics Service Request 		| logistic:service_enquiry_request
#
# 	View Wishlist 							| Remove
# 	Wishlist Add to Cart					| Wishlist Notification
#
# 	CheckOut - CustomerSalesOrder			| sales:customer_sales_order
# 	CustomerSalesOrder Status Tracking 		| sales:sales_order_tracking
# #########################################################################


def view_cart(request):
    print("reached view_cart")
    return render(request,'view_cart.html')

def product_quote(request):
    print("reached product_quote")
    return render(request,'product_quote.html')

def checkout(request):
    print("reached checkout")
    return render(request,'checkout.html')

# def sales_order(request):
#     print("reached sales_order")
#     return render(request,'confirm_sales_order.html')
#
# def sales_order_tracking(request):
#     print("reached sales_order_tracking")
#     return render(request,'sales_order_tracking.html')

def view_wishlist(request):
    print("reached view_wishlist")
    return render(request,'view_wishlist.html')

def wishlist_add_to_cart(request):
    print("reached wishlist_add_to_cart")
    return render(request,'wishlist_add_to_cart.html')
