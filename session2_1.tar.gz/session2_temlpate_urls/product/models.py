from django.db import models

# Create your models here.
# CRUD
# <product>
# 	Product
# 	ProductSpecification		| Size, Color, Width, Height, etc
# 	ProductCategory
