from django.db import models

# Create your models here.
# <business>
# 	ProductFeatured
# 	ProductBestPromoted
# 	ProductBestSelling
# 	ProductBestRated
# 	ProductNewArrival
# 	ProductOnSale
# 	ProductOfferDeal			| Exchange, Buy1Get1, Discount, etc
# 	ProductRecentlyViewed
# 	ProductBrands
# 	ProductTrends2020
# 	ProductPopularCategory