from django.db import models

# Create your models here.
# <payment>
# 	SalesPaymentRecord
# 	SalesPaymentTransactionLog
# 	PurchasePaymentRecord
# 	PurchasePaymentTransactionLog
# 	LogisticsPaymentRecord
# 	LogisticsPaymentTransactionRecord
