from django.db import models

# Create your models here.
# <purchase>
# 	SupplierDetail
# 	ProductSupplier
# 	ProductEnquiryRequest
# 	ProductSupplierQuotation
# 	PurchaseOrder
# 	PurchaseInvoice
